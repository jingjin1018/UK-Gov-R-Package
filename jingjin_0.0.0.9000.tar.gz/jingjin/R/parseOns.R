#' Parse Office for National Statistics (ONS) data
#' 
#' ONS time series data is in a standard CSV format.
#' Code below removes the copyright symbol, selects relevant rows (with date year
#' beginning '201'), thus removing text comments at the end, and parse dates.
#' 
#' @param d A dataframe from a raw ONS CSV
#' @return Dataframe with relevant rows only and dates parsed
#' @import randomForest
#' @export
#' @examples
#' dispIncomeUrl <- 'http://www.ons.gov.uk/ons/datasets-and-tables/downloads/csv.csv?dataset=ukea&cdid=IHXZ'
#' dispIncome <- tryCatch(read.csv(dispIncomeUrl, stringsAsFactors = FALSE), 
#'														err=function(cond) 'err')
#' dispIncome <- parseOns(dispIncome)
#' @author David Wilks

parseOns <- function(d) {
				if (!is.data.frame(d)) stop ('Parameter must be a dataframe')
				d[,1] <- as.character(d[,1])
				d[,1] <- sub('\xa9','',d[,1])
				d <- d[grep('201',d[,1],fixed=TRUE),]
				dataIsMonthly <- length(grep('JAN',d[,1],fixed=TRUE))>0
				if (dataIsMonthly) {
					d <- d[nchar(d[,1]) == 8,]
					d[,1] <- as.Date(paste(d[,1], '1'), format = '%Y %b %d')
				} else {
					d <- d[nchar(d[,1]) == 7,]
					d[,1] <- as.Date(paste(substr(d[,1],1,4), 
							as.numeric(substr(d[,1],7,7))*3-2,'1'),format='%Y %m %d')						
				}
				d[,2] <- as.numeric(as.character(d[,2]))
				names(d) <- c('dt','value')
				d
				}