#' Get services with satisfaction data
#'
#' Seach dataframe column names for satisfaction data
#' 
#' Satisfaction data appears in multiple columns, one of which for each
#' service has a name ending in 'rating_5'. We return a character vector
#' of services names (the service name is the first element in the URL).
#' This function is intended to be used on dataframes with names formatted 
#' like daily or sparse.
#' 
#' @param dFrame A dataframe
#' @return A character vector of all services in that dataframe with satisfaction data
#' @export
#' @examples
#' getSatisServices(sparse)
#' @author David Wilks

getSatisServices <- function(dFrame) {
	if (!is.data.frame(dFrame)) stop ('Parameter must be a dataframe')
	satisIndex <- subsetByKeywords(dFrame, varKeywords = 'rating_5')
	urlElements <- strsplit(names(dFrame)[satisIndex], split="/")
	warn <- 'Input data format may be wrong - see ?getSatisServices'
	if (length(urlElements) < 2) warning (warn)	
	as.character(lapply(urlElements, function (x) x[[1]]))
}