#' Aggregate across all daily data
#'
#' Apply a custom function across both sparse and daily.
#' 
#' Each column in sparse, daily and hourly is one variable from one JSON URL.
#' Several columns may be needed to define a service and they may needed to be
#' aggregated in non-straightforward ways. This function takes a function which
#' identifies all the relevant service names from sparse and daily and applies a 
#' custom aggregation function across them.
#' See getSatisfaction() for an example of how to build on this.
#' 
#' @param getServices A function identifying services with relevant data
#' @param f A function to aggregate data from each service
#' @return A dataframe aggregating data from daily and sparse
#' @export
#' @examples
#' aggData(getSatisServices, getServiceSatisfaction)
#' @author David Wilks

aggData <- function(getServices, f) {
	if (!is.function(getServices)||!is.function(f)) {
		stop ('Parameters not of expected types - see ?aggData')
	}
	sparseData <- aggDf(sparse, getServices, f)
	dailyData <- aggDf(daily, getServices, f)
	merge(x = dailyData, y = sparseData, by = "dt", all.x=TRUE)
}