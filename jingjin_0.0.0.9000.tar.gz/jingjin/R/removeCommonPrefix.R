#' The removeCommonPrefix function
#' 
#' Removes the largest common prefix of all the entries of a character vector.
#' @param charVector A character vector contains all the strings one wants to remove the largest common prefix.
#' @return A character vector with the common prefix of all the entries removed.
#' @export
#' @examples
#' doi <- getDataOfInterest("2014-04-01", "2015-03-05", "register-to-vote", c("18-24", "25-34", "35-44", "45-54", "55-64", "65-74"), daily)
#' names <- names(doi)[-1]
#' removeCommonPrefix(names)
#' @author Jing Jin


removeCommonPrefix <- function(charVector) {
  substr <- charVector
  init <- sapply(substr, function(x) {substring(x, 1, 1)})
  while(length(unique(init)) == 1) {
    substr <- sapply(substr, function(x) {substring(x, 2)})
    init <- sapply(substr, function(x) {substring(x, 1, 1)})
  }
  substr
}
