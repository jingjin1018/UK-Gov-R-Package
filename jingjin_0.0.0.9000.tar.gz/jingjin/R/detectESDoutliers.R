#' Detect ESD Outliers
#' 
#' Find positions of items > 3 standard deviations from their column mean. 
#' In the example, we choose dimensions to ignore the initial date column
#'
#' @param dFrame A dataframe with all columns numeric
#' @return A logical matrix showing positions of outliers in the dataframe
#' @export
#' @examples
#' dailyOutliers <- detectESDoutliers(daily[,2:ncol(daily)])
#' @author David Wilks

detectESDoutliers <- function (dFrame) {
	if (!is.data.frame(dFrame)) {
		stop ('Parameter not of expected type - see ?detectESDoutliers')
	}
	means <- sapply(dFrame,function (x) mean(x,na.rm=TRUE))
	sds <- sapply(dFrame,function (x) sd(x,na.rm=TRUE))
	esdLower <- means - 3 * sds
	esdUpper <- means + 3 * sds
	m <- as.matrix(dFrame)
	out <- t((t(m) < esdLower) | (t(m) > esdUpper))
	out[is.na(out)] <- FALSE
	out
}

