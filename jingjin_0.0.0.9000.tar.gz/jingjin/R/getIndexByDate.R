#' The getIndexByDate function
#' 
#' Returns the index of the (first) match of a specific date in certain period.
#' @param date, The date to be matched. Valid format: "YYYY-MM-DD".
#' @param dateRange, The period to be matched against. Valid format of each entry: "YYYY-MM-DD".
#' @export
#' @examples
#' \donttest{
#' getIndexByDate("2015-03-11", c("2015-03-10", "2015-03-11", "2015-03-12"))
#' }
#' @author Jing Jin

getIndexByDate <- function(date, dateRange) {
  if(!grepl("\\d{4}-(0|1)\\d-\\d{2}", date)) {
    stop(paste("Invalid date ", date, ". Please change the date format to \"YYYY-MM-DD\".\n", sep=""))
  }
  date <- as.Date(date, "%Y-%m-%d")
  dateRange <- as.Date(substring(dateRange, 1, 10), "%Y-%m-%d")
  dateIndex <- match(date, dateRange)
  if(is.na(dateIndex)) {
    stop(paste("Date ", date, " is not in the valid range: (", dateRange[1], " - ", dateRange[length(dateRange)], ").\n", sep=""))    
  }
  dateIndex
}
  