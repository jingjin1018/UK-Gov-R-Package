#' Aggregate services
#'
#' Apply a custom function across selected fields
#' 
#' Each column in sparse, daily and hourly is one variable from one JSON URL.
#' Several columns may be needed to define a service and they may needed to be
#' aggregated in non-straightforward ways. This function takes a vector of
#' service names and a custom aggregation function to apply across them.
#' See getSatisfaction() for an example of how to build on this.
#' 
#' @param dFrame A dataframe
#' @param services A character vector of service names
#' @param f A function to be applied on each service name
#' @return A dataframe produced by applying the function to those services
#' @export
#' @examples
#' aggServices(sparse, c('renew-patent','prison-visits'), getServiceSatisfaction)
#' @author David Wilks

aggServices <- function(dFrame, services, f) {
	if (!is.data.frame(dFrame)||!is.character(services)||!is.function(f)) {
		stop ('Parameters not of expected types - see ?aggServices')
	}
	servicesData <- data.frame(lapply(services, function(x) f(dFrame,x)))
	colnames(servicesData) <- services
	servicesData$dt <- dFrame$dt
	servicesData
}