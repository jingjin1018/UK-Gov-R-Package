#' Column-wise subset of dataframe
#' 
#' daily, sparse and hourly each have ugly column names made from concatenating 
#' the source URL to variable names.
#' This function builds on dataFrameIndex() to return a logical index matching
#' the URL and variable name parameters.
#' 
#' @param dFrame A dataframe
#' @param urlKeywords A character vector of URL elements (optional)
#' @param varKeywords A character vector of variable names (optional)
#' @param dfIndex A list produced by dataFrameIndex (optional)
#' 
#' @return A logical vector indicating the columns to be selected
#' @export
#' @examples
#' names(daily)[subsetByKeywords(daily, c('browsers','chevening-applications'))]
#' names(daily)[subsetByKeywords(daily, 'browsers', 'Safari')]
#' names(daily)[subsetByKeywords(daily, varKeywords = c('Safari','satisfied'))]
#' @author David Wilks

subsetByKeywords <- function(dFrame, urlKeywords, varKeywords, dfIndex) {
    if (missing(dFrame)||(missing(urlKeywords)&&missing(varKeywords))||
        is.null(names(dFrame))||(!missing(urlKeywords)&&!is.character(urlKeywords))
        				||(!missing(varKeywords)&&!is.character(varKeywords))) {
        stop ("Must have a named dataframe and 1 or 2 character vectors")
	}
    if (missing(dfIndex)) dfIndex <- dataFrameIndex(dFrame)
    fUrl <- function (x) length(intersect(urlKeywords,x)) > 0
    fVar <- function (x) length(intersect(varKeywords,x)) > 0
    if (missing(varKeywords)) return(as.logical(lapply(dfIndex[[1]], fUrl)))
    if (missing(urlKeywords)) return(as.logical(lapply(dfIndex[[2]], fVar)))
    as.logical(lapply(dfIndex[[1]], fUrl)) & as.logical(lapply(dfIndex[[2]], fVar))
}