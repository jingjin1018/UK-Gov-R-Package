#' The selectFigureType function
#' 
#' Select the type of figure one wants to visualize the data.
#' @param dataset, The data to be plotted.
#' @param type, A string describes the type of figures one wants to plot, including "area" chart, "line" chart etc.
#' @export
#' @return Returns a dataset ready to be plotted with selected type. 
#' @examples
#' doi <- getDataOfInterest("2014-04-01", "2015-03-05", "register-to-vote", "age_band", daily)
#' doiLineChart <- selectFigureType(doi, "line")
#' @author Jing Jin

selectFigureType <- function(dataset, type) {
  types <- c("area", "line", "bar", "lattice")
  if(type %in% types) {
    class(dataset) <- type
  } else {
    stop(paste("Please select the plot type from the following choices: \"", paste(types, collapse="\", \""), "\".", sep=""))
  }
  dataset
}
