#' Get Service Satisfaction
#' 
#' User satisfaction data appears in 5 fields (rating_1 ... rating_5) per service
#' rating_1 is taken to indicate 0% satisfaction; rating_5 100% satisfaction.
#' This function aggregates all 5 columns into one score for a particular service.
#'
#' @param dFrame A dataframe
#' @param service The name of a service
#' @return A numeric vector of satisfaction scores
#' @export
#' @examples
#' getServiceSatisfaction(sparse, 'renew-patent')
#' @author David Wilks

getServiceSatisfaction <- function(dFrame, service) {
	if (!is.data.frame(dFrame)||!is.character(service)||length(service) > 1) {
		stop ('Parameters not of expected types - see ?aggDf')
	}
	str <- names(dFrame)[subsetByKeywordsPartialRegex(dFrame,service,'rating_5')]
	if (length(str)==0) {
		warning ('That service could not be matched')
		return(NULL)
	}
	f <- function(i) as.numeric(dFrame[,gsub('_5',paste('_',i,sep=''),str)])
	u <- lapply(1:5, f)
	(0.25 * u[[2]] + 0.5 * u[[3]] + 0.75 * u[[4]] + u[[5]]) / 
		(u[[1]] + u[[2]] + u[[3]] + u[[4]] + u[[5]]) 
}