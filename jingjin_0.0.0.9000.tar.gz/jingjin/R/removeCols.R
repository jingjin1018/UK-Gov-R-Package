#' The removeCols function
#' 
#' This function removes certain columns relating to the keywords specified 
#' in a list from the dataset.
#' @param dataset, The dataset one wants to remove data from.
#' @param removeList, A list specifies the keywords. All the data that's related to those keywords will be removed from the dataset.
#' @export
#' @examples
#' \donttest{
#' doi <- getDataOfInterest("2014-04-01", "2015-03-05", "register-to-vote", "age_band", daily)
#' data <- removeCols(doi, c("age_band__21-30", "age_Band__25-34"))
#' }
#' @author Jing Jin
#' 
removeCols <- function(dataset, removeList) {
  if (length(removeList)==0) { # this if block added by dwilks
    warning("Empty remove list")
    return(dataset)
  }
  oldClass <- class(dataset)
  indexes <- vector("numeric")
  for(i in 1:length(removeList)) {
    newIndexes <- agrep(removeList[i], names(dataset), ignore.case = TRUE, max.distance = 0)
    if(sum(!is.na(newIndexes)) == 0) {
      warning(paste("Miss data - ", removeList[i], ": no such legend.\n"))
      return(dataset)
    } else {
      indexes <- union(indexes, newIndexes)
    }
  }
  dataset <- dataset[-c(indexes)]
  class(dataset) <- oldClass
  dataset
}
