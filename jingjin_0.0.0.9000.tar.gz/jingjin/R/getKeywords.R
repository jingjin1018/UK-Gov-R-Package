utils::globalVariables(c("daily", "hourly", "sparse"))

#' Get keywords
#'
#' Daily, hourly and sparse each have ugly column names made from concatenating URLs
#' to variable names. This function parses the URL elements and variable names into
#' neat a neat frequency table for data exploration.
#' 
#' @param dFs A list of data.frames
#' @return A list with 2 frequency tables (for URL elements and variable names)
#' @import plyr
#' @importFrom reshape cast
#' @export
#' @examples
#' k <- getKeywords(list(daily, hourly, sparse))

getKeywords <- function(dFs){

	if (!is.list(dFs)||!all(as.logical(lapply(dFs,is.data.frame))==TRUE)) {
		stop ('Parameters not of expected types - see ?getKeywords')
	}

	urlTable <- data.frame(x=as.character(), freq=as.integer(), name=as.character(), stringsAsFactors=FALSE)
	varTable <- data.frame(x=as.character(), freq=as.integer(), name=as.character(), stringsAsFactors=FALSE)
	
	for (i in 1:length(dFs)){
		urlDf <- as.data.frame(count(unlist(dataFrameIndex(dFs[[i]])[[1]])))
		urlDf['name'] <- paste('df',i,sep='')
		urlTable <- rbind(urlTable, urlDf)
		varDf <- as.data.frame(count(unlist(dataFrameIndex(dFs[[i]])[[2]])))
		if (nrow(varDf) > 0) {
			varDf['name'] <- paste('df',i,sep='')
			varTable <- rbind(varTable, varDf)
		}
	}
	
	list(cast(urlTable, x ~ name, value = 'freq', fill = 0), 
			cast(varTable, x ~ name, value = 'freq', fill = 0))
}


