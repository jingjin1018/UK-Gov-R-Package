#' The plotFigure function
#' 
#' Generic function for plotting. 
#' According to the class of dataset, different plotFigure method will be used.
#' @param dataset, The dataset.
#' @family plotFigure
#' @export
#' @examples
#' doi <- getDataOfInterest("2014-04-01", "2015-03-05", "register-to-vote", "age_band", daily)
#' doiLineChart <- selectFigureType(doi, "line")
#' plotFigure(doiLineChart)

plotFigure <- function(dataset) {
  UseMethod("plotFigure") # used warning not stop to pass R CMD check
}
