#' Column-wise subset of dataframe (partial / regex matching) 
#' 
#' daily, sparse and hourly each have ugly column names made from concatenating 
#' the source URL to variable names.
#' This function builds on dataFrameIndex() to return a logical index matching
#' the URL and variable name parameters.
#' 
#' @param dFrame A data.frame
#' @param keywords1 A character vector of URL elements or variable names
#' @param keywords2 Second character vector of URL elements or variable names (optional)
#'
#' @return A logical vector indicating the columns to be selected
#' @export
#' @examples
#' names(daily)[subsetByKeywordsPartialRegex(daily, c('browsers','chevening-applications'))]
#' names(daily)[subsetByKeywordsPartialRegex(daily, 'browsers', 'Safari')]
#' @author David Wilks

subsetByKeywordsPartialRegex <- function(dFrame, keywords1, keywords2) {
	if (missing(dFrame)||missing(keywords1)||!is.data.frame(dFrame)
				||!is.character(keywords1)||is.null(names(dFrame)) 
				||(!missing(keywords1)&&!is.character(keywords1))) {
				stop ("Must have a named dataframe and 1 or 2 character vectors")
	}
	f <- function(v) unique(unlist(lapply(v, function (x) grep(x, names(dFrame)))))
	if (missing(keywords2)) return(f(keywords1))
	if (!is.character(keywords2)) stop ("Only pass in a dataframe and char vectors")
	intersect(f(keywords1), f(keywords2))
}