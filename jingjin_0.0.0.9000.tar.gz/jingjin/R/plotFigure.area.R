#' The plotFigure.area function
#' 
#' This function implement an area chart method for "area" class argument of the 
#' generic plotFigure function.
#' @param dataset, A dataset of "area" class.
#' @family plotFigure
#' @export
#' @import ggplot2
#' @examples
#' doi <- getDataOfInterest("2014-04-01", "2015-03-05", "register-to-vote", "age_band", daily)
#' doiAreaChart <- selectFigureType(doi, "area")
#' plotFigure(doiAreaChart)
#' @author Jing Jin

plotFigure.area <- function(dataset) {
  df <- toDataFrame(dataset)
  gg <- ggplot2::ggplot(df, ggplot2::aes(x = date, y = data, fill = factor(legend)))
  gg <- gg + ggplot2::geom_area(colour="white", size = 0.2, alpha = 0.4)
  gg <- gg + ggplot2::theme(legend.position="right") + ggplot2::scale_fill_discrete(name="Legend")
  gg
}
