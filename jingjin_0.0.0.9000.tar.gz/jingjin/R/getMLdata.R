#' Select columns to pass to machine learner
#' 
#' machineLearnData returns a list of 2 dataframes: training and recent.  
#' This function if applied to one of these dataframe will return the list of 
#' columns to pass to the machine learner. It excludes current data columns (except
#' for the one being predicted) thus applying the necessary time lag. 
#' 
#' @param x Dataframe intended to be a list element returned by machineLearnData
#' @return Data Frame with columns not to be used by machine learners removed
#' @export
#' @examples
#' m <- machineLearnData(daily[,c('dt',names(daily)[subsetByKeywords(daily,'register-to-vote')])])
#' testDf <- getMLdata(m$train)  
#' @author David Wilks

getMLdata <- function(x) {
	if (!is.data.frame(x)) stop ('Parameter must be dataframe - see ?getMLdata')
	x <- x[,c(1,grep('__MLX',names(x)))]
	if (ncol(x) == 1) warning ('Input data may be in wrong format - see ?getMLdata') 
	x
}