#' This code is be David Wilks

#' @name daily
#' @title daily
#' @details Hourly transactional data
#' @docType data
#' @author David Wilks \email{david.wilks@@digital.cabinet-office.gov.uk}
#' @references \url{"https://445e25c38fe5febd57a1ba9aaadcfb38a45b1d60.googledrive.com/host/0BxMhz1SiiE9Ca2lITU1femVvSkk"}
#' @keywords data
NULL

#' @name hourly
#' @title hourly
#' @details Hourly transactional data
#' @docType data
#' @author David Wilks \email{david.wilks@@digital.cabinet-office.gov.uk}
#' @references \url{"https://33e8874943d6cf5d9b8f074df58eeea08c58c23a.googledrive.com/host/0BxMhz1SiiE9CSGRSYkh1T3VEaFU"}
#' @keywords data
NULL

#' @name sparse
#' @title sparse
#' @details Sparsely populated daily transactional data
#' @docType data
#' @author David Wilks \email{david.wilks@@digital.cabinet-office.gov.uk}
#' @references \url{"https://321930d0d57e9855f0b67a985e63b0a402e9eadf.googledrive.com/host/0BxMhz1SiiE9CcXpsSmtnS3FBdFk"}
#' @keywords data
NULL

#' @name govUkStartsBySourceMedium
#' @title govUkStartsBySourceMedium
#' @details User journeys on GOV.UK
#' @docType data
#' @author David Wilks \email{david.wilks@@digital.cabinet-office.gov.uk}
#' @references \url{"https://25eff1d288113bc8575552215cb5ccd9713d5ec4.googledrive.com/host/0BxMhz1SiiE9CU0Q1YnNmc2pDMTg"}
#' @keywords data
NULL

#' @name govUkContent
#' @title govUkContent
#' @details Performance of content on GOV.UK
#' @docType data
#' @author David Wilks \email{david.wilks@@digital.cabinet-office.gov.uk}
#' @references \url{"https://ede73a1663564a3532d6ee41e478f5a872ca4292.googledrive.com/host/0BxMhz1SiiE9CTnVWdG5Ob1ZzWTQ"}
#' @keywords data
NULL

#' @name transactionalServiceSummaries
#' @title transactionalServiceSummaries
#' @details Transactional service summary data
#' @docType data
#' @author David Wilks \email{david.wilks@@digital.cabinet-office.gov.uk}
#' @references \url{"https://3341d7315c73f3212f6534beaa7863b78cb50358.googledrive.com/host/0BxMhz1SiiE9CQ2JLUlV4TnloZTg"}
#' @keywords data
NULL

#' @name inflation
#' @title inflation
#' @details Inflation index time series from Office for National Statistics
#' @docType data
#' @author David Wilks \email{david.wilks@@digital.cabinet-office.gov.uk}
#' @references \url{"http://www.ons.gov.uk/ons/datasets-and-tables/downloads/csv.csv?dataset=mm23&cdid=D7BT"}
#' @keywords data
NULL

#' @name unemployment
#' @title unemployment
#' @details Unemployment time series from Office for National Statistics
#' @docType data
#' @author David Wilks \email{david.wilks@@digital.cabinet-office.gov.uk}
#' @references \url{"http://www.ons.gov.uk/ons/datasets-and-tables/downloads/csv.csv?dataset=lms&cdid=MGSC"}
#' @keywords data
NULL

#' @name dispIncome
#' @title dispIncome
#' @details Disposable income time series from Office for National Statistics
#' @docType data
#' @author David Wilks \email{david.wilks@@digital.cabinet-office.gov.uk}
#' @references \url{"http://www.ons.gov.uk/ons/datasets-and-tables/downloads/csv.csv?dataset=ukea&cdid=IHXZ"}
#' @keywords data
NULL
