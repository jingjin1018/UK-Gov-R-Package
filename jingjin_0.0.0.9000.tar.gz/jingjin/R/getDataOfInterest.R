#' The getDataOfInterest function
#'
#' Returns a subset of data in a data.frame format which contains data during 
#' a specified period and corresponding to particular variables and URLs.
#' @param startDate, The first date of interest. Valid format: "YYYY-MM-DD".
#' @param endDate, The last date of interest(Optional). Valid format: "YYYY-MM-DD".
#' @param urlKeywords, A character vector of URL elements (optional).
#' @param varKeywords, A character vector of variable names (optional).
#' @param dataset, Original set in the data.frame format which contains the data to be subsetted.
#' @export
#' @examples
#' getDataOfInterest("2014-04-01", "2015-03-05", "register-to-vote", "age_band", daily)
#' @author Jing Jin

getDataOfInterest <- function(startDate, endDate = startDate, urlKeywords, varKeywords, dataset) {
  col_date <- which(names(dataset) == "dt")
  rows <- subsetByDates(startDate, endDate, dataset$dt)
  cols <- subsetByKeywords(dataset, urlKeywords, varKeywords)
  names(dataset)[col_date] <- "date"
  cols[col_date] <- TRUE
  doi <- dataset[rows, cols]  
}
