#' Reformat dataframe for machine learners
#' 
#' machineLearnData returns a dataframe wrangled so that values for the n days prior
#' to each row appear as extra columns. This allows machine learners to be trained on
#' timeseries data. This package applies it to randomForest, but the output from 
#' machineLearnData would support other machine learners.
#' I adapted a small amount of code to remove empty dataframe rows from:
#' http://stackoverflow.com/questions/6437164/removing-empty-rows-of-a-data-file-in-r
#'
#' @param dFrame A dataframe with dates in first column and other columns numeric
#' @param nonNullThreshold Fraction of columns to be non-null for row to be meaningful 
#' @param predictPeriods Number of periods ahead to predict 
#' @param trainPeriods Number of previous periods to use in training  
#' @param period Periodicity of data ('day', 'week', 'month' or 'quarter') 
#' @return List of dataframes - 'train' = training data and 'recent' = recent data
#' @importFrom timeSeries interpNA
#' @importFrom lubridate is.Date
#' @export
#' @examples
#' d <- daily[,c('dt',names(daily)[subsetByKeywords(daily,'register-to-vote')])]
#' m <- machineLearnData(d)
#' @author David Wilks

machineLearnData <- function(dFrame, nonNullThreshold = 0.75, predictPeriods = 7, 
												trainPeriods = 14, period = 'day') {

	if (!is.data.frame(dFrame) || !is.Date(dFrame[,1]) || ncol(dFrame) < 3 ||
			!all(as.logical(lapply(dFrame[,2:ncol(dFrame)],is.numeric)) == TRUE) ||
			!is.numeric(predictPeriods) || !is.numeric(trainPeriods) ||
			!is.numeric(nonNullThreshold) || nonNullThreshold < 0 ||
			nonNullThreshold > 1) {
		stop ('Parameters not of expected types - see ?machineLearnData')
	}
	period = match.arg(period,c('day', 'week', 'month', 'quarter'))
	dts <- dFrame[,1]
	dtsAll <- seq.Date(dts[1],dts[length(dts)],by=period)
	interpNonNull <- function(x) {
		if (sum(!is.na(x)) >=2) return(interpNA(x))
		x
	}	
	expandCol <- function(x) {
		a <- rep(NA,length(dtsAll))
		a[match(dts, dtsAll)] <- x
		interpNonNull(a)
	}	
	dInterp <- cbind(dts = dtsAll, 
					as.data.frame(lapply(dFrame[,2:ncol(dFrame)], expandCol)))
	d <- dInterp[,!is.na(dInterp[nrow(dInterp),])]
	if (length(d) == 0) stop ('Most recent variables are all NA')
	firstRowEnoughValues <- 
		sum(rowSums(!is.na(d[,2:ncol(d)])) / (ncol(d)-1) < nonNullThreshold) + 1
	if (firstRowEnoughValues == nrow(d)) stop ('Your data has too many NAs')
	d <- d[firstRowEnoughValues:nrow(d),]
	nR <- nrow(d)
	nC <- ncol(d)
	d1 <- d[,2:nC]
	if (nR - trainPeriods - predictPeriods < 1) {
		stop ('Your data has too many NAs and/or not enough rows')
	}
	dRecent <- d[(nR - trainPeriods - predictPeriods):nR,]
	nRecent <- nrow(dRecent)
	lastRow <- as.data.frame(t(rep(NA,nC-1)))
	lastRowBlock <- lastRow[rep(1,predictPeriods),]	
	names(lastRowBlock) <- names(d1)
	d1 <- rbind(d1[(predictPeriods+1):nR,],lastRowBlock)	
	colnames(d1) <- paste(colnames(d),'__MLX',1,sep='')[2:nC]
	d <- cbind(d, d1)
	colnames(dRecent)[2:nC] <- colnames(d1)
	dRecent1 <- dRecent[,2:nC] 
	for (i in 2:trainPeriods) {
		names(lastRow) <- names(d1)
		d1 <- rbind(d1[2:nR,],lastRow)
		colnames(dRecent1) <- colnames(d1)	
		colnames(d1) <- paste(colnames(d),'__MLX',i,sep='')[2:nC]
		d <- cbind(d, d1) 	
		dRecent1 <- rbind(dRecent1[2:nRecent,],lastRow)	
		colnames(dRecent1) <- colnames(d1)
		dRecent <- cbind(dRecent, dRecent1)
	}	
	list(train = d[rowSums(is.na(d))==0,], recent = dRecent[1:predictPeriods,])
}