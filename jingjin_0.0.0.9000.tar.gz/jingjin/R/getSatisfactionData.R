#' Get satisfaction data for all services
#' 
#' User satisfaction data appears in 5 fields (rating_1 ... rating_5) per service
#' rating_1 is taken to indicate 0% satisfaction; rating_5 100% satisfaction.
#' This function calls subfunctions which make one series of scores per service,
#' do this for all services in sparse and daily with satisfaction data and merges
#' all this data into a single dataframe to return.
#'
#' @return A dataframe of all satisfaction data from daily and sparse
#' @export
#' @examples
#' getSatisfactionData()
#' @author David Wilks

getSatisfactionData <- function() {
	aggData(getSatisServices, getServiceSatisfaction)
}