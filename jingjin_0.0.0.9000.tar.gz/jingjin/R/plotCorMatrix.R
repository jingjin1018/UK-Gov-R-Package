utils::globalVariables(c("var1", "var2", "Correlation"))

#' The plotCorMatrix function
#' 
#' This function validate the correlation matrix and visualize a valid one with a level plot. 
#' @param corMatrix, A correlation matrix.
#' @seealso \code{\link{correlationMatrix}}
#' @export
#' @import ggplot2
#' @import reshape2
#' @examples
#' doi <- getDataOfInterest("2014-04-01", "2015-03-05", "register-to-vote", c("18-24", "25-34", "35-44", "45-54", "55-64", "65-74"), daily)
#' cor <- correlationMatrix(doi)
#' plotCorMatrix(cor)
#' @author Jing Jin

plotCorMatrix <- function(corMatrix) {
  if(any(corMatrix > 1) | any(corMatrix < -1)) {
    stop("Exist invalid correlation coefficient. Valid range: [-1, 1]")
  }
  rownames(corMatrix) <- removeCommonPrefix(rownames(corMatrix))
  colnames(corMatrix) <- removeCommonPrefix(colnames(corMatrix))
  gg <- ggplot2::ggplot(reshape2::melt(corMatrix, varnames = c("var1", "var2"), value.name="Correlation"), ggplot2::aes(var1, var2, fill = Correlation)) + ggplot2::geom_tile()
  gg <- gg + ggplot2::theme(axis.text.x = ggplot2::element_text(lineheight = 0.9, colour = "grey50", hjust = 1, angle = 90))
  gg <- gg + ggplot2::theme(aspect.ratio = 1) + ggplot2::scale_fill_continuous(name="Correlation")
  gg
}