#' Moving weekly average
#' 
#' HEAVILY BASED on StackOverflow
#' http://stackoverflow.com/questions/743812/calculating-moving-average-in-r
#' 
#' @param arr A numeric vector
#' @return A numeric vector with first 6 items null
#' @export
#' @details
#' Calculates moving 7-item average and returns numeric vector with first 6 items null
#' @examples
#' movingWeeklyAvg(c(9,3,5,4,5,4,3,6,2))
#' @author David Wilks

movingWeeklyAvg <- function(arr){
	if (!is.numeric(arr) || sum(is.na(arr)) > 0 || length(arr) < 8) {
		stop ('Must be non-null numeric vector of at least length 8')
	}
	res = rep(NA,length(arr))
	for(i in 7:length(arr)) {res[i] <- mean(arr[(i-6):i])}
	res
}