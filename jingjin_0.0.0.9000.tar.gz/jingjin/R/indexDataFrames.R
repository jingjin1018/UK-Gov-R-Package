utils::globalVariables(c("daily", "hourly", "sparse"))

#' Index important dataframes
#'
#' Apply the function dataFrameIndex to daily, hourly and sparse.
#' They each have ugly column names made from concatenating the source URL to
#' variable names. This function parses the URL elements and variable names into
#' neat sublists to support subsetting and data exploration.
#' 
#' @param dFs A list of data.frames
#' @return A list of outputs from dataFrameIndex
#' @export
#' @examples
#' mainTableIndexes <- indexDataFrames()
#' @author David Wilks

indexDataFrames <- function(dFs = list(daily, hourly, sparse)) {
	lapply(dFs, dataFrameIndex)
}