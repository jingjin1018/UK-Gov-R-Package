utils::globalVariables(c("inflation", "dispIncome", "unemployment"))

#' Update economic dataframes from Office for National Statistics
#' 
#' Data is in a standard CSV format on URLs which remain the same when updated.
#' This function downloads the data whilst handling and reporting download failures. 
#' 
#' @return NULL; produces new tables in the global environment
#' @import RCurl
#' @export
#' @details Updates key tables from CSV URLs hosted on Google Drive
#' @examples
#' \donttest{
#' getEconomicData()
#' }
#' @author David Wilks

getEconomicData <- function(){
	dispIncomeUrl <- 'http://www.ons.gov.uk/ons/datasets-and-tables/downloads/csv.csv?dataset=ukea&cdid=IHXZ'
	inflationUrl <- 'http://www.ons.gov.uk/ons/datasets-and-tables/downloads/csv.csv?dataset=mm23&cdid=D7BT'
	unemploymentUrl <- 'http://www.ons.gov.uk/ons/datasets-and-tables/downloads/csv.csv?dataset=lms&cdid=MGSC'
	
	if (!url.exists(dispIncomeUrl)) {
		warning ('dispIncome table download failed')
	} else {
		dispIncome <- read.csv(dispIncomeUrl, stringsAsFactors = FALSE)
		dispIncome <- parseOns(dispIncome)
		assign('dispIncome', dispIncome, envir = .GlobalEnv)
	}
	if (!url.exists(inflationUrl)) {
		warning ('Inflation table download failed')
	} else {
		inflation <- read.csv(inflationUrl, stringsAsFactors = FALSE)
		inflation <- parseOns(inflation)
		assign('inflation', inflation, envir = .GlobalEnv)
	}
	if (!url.exists(unemploymentUrl)) {
		warning ('unemployment table download failed')
	} else {
		unemployment <- read.csv(unemploymentUrl, stringsAsFactors = FALSE)
		unemployment <- parseOns(unemployment)
		assign('unemployment', unemployment, envir = .GlobalEnv)
	}	
}