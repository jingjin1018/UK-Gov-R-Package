#' The correlationMatrix function
#' 
#' Returns a correlation matrix of all the variables in a dataset.
#' @param dataset A data.frame contains all the variables one wants to calculate the correlation matrix from.
#' @export
#' @examples
#' doi <- getDataOfInterest("2014-04-01", "2015-03-05", "register-to-vote", c("18-24", "25-34", "35-44", "45-54", "55-64", "65-74"), daily)
#' cor <- correlationMatrix(doi)
#' @author Jing Jin

correlationMatrix <- function(dataset) {
  dataset <- dataset[,-1]
  dataset <- na.omit(dataset)
  names(dataset) <- removeCommonPrefix(names(dataset))
  cor(dataset)
}
