#' Index a dataframe
#'
#' Make list to be used as dataframe index
#' 
#' This function is intended for the dataframes sparse, daily and hourly.
#' They each have ugly column names made from concatenating the source URL to
#' variable names. The function parses the URL elements and variable names into
#' 2 neat sublists to support subsetting and data exploration.
#' 
#' @param dF A dataframe
#' @return A list
#' @export
#' @examples
#' dailyIndex <- dataFrameIndex(daily)
#' @author David Wilks

dataFrameIndex <- function(dF){						
	if (!is.data.frame(dF)) { 
		stop ('This function is for specific dataframes - see ?dataFrameIndex')
	}
	varList <- lapply(names(dF), function(x) unlist(strsplit(x, split="__")))
	urlList <- lapply(varList, function(x) unlist(strsplit(x[1], split="/")))
	varList <- lapply(varList, function(x) x[-1])
	if (length(urlList) <= 1 || length(varList) <= 1) {
		warning ('Dataframe not in expected format - see ?dataFrameIndex')
	}
	list(urlList, varList)
}