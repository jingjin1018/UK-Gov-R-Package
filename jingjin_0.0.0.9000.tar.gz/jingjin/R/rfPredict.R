#' Predict time series using a Random Forest
#' 
#' machineLearnData returns reformatted data with 'train' and 'recent' data with
#' time series reformatted into extra columns.  
#' This uses a Random Forest to predict a time series from this data.
#' The flexible ... parameter gives control over Random Forest parameters such as ntree 
#' 
#' @name rfPredict
#' @title rfPredict
#' @param dFrame A dataframe with dates in first column and other columns numeric
#' @param toPredict A character string giving the name of the variable to predict
#' @param nonNullThreshold Fraction of columns to be non-null for row to be meaningful 
#' @param predictPeriods Number of periods ahead to predict 
#' @param trainPeriods Number of previous periods to use in training  
#' @param period Periodicity of data ('day', 'week', 'month' or 'quarter') 
#' @param ... Other parameters to pass to the Random Forest 
#' @return Numeric vector predicting next values of time series
#' @import randomForest
#' @export
#' @examples
#' df <- daily[,c('dt',names(daily)[subsetByKeywords(daily,'register-to-vote')])]
#' rfPredict(df, 'register.to.vote.volumetrics__count____age_band__45.54', ntree = 50)
#' @author David Wilks

rfPredict <- function(dFrame, toPredict, nonNullThreshold = 0.75, predictPeriods = 7, 
											trainPeriods = 14, period = 'day', ...) {	
	d <- machineLearnData(dFrame, nonNullThreshold, predictPeriods, trainPeriods, period)
	rf <- randomForest(getMLdata(d$train),d$train[[toPredict]],keep.forest=TRUE, ...)
	p <- predict(rf,getMLdata(d$recent))
	names(p) <- NULL
	p
	}
