utils::globalVariables(c("daily", "hourly", "sparse", "govUkStartsBySourceMedium","govUkContent",
															"transactionalServiceSummaries"))

#' Update dataframes from Internet URLs
#' 
#' Data is in a standard CSV format on URLs which remain the same when updated.
#' This function downloads the data whilst handling and reporting download failures. 
#' 
#' @return NULL; produces new tables in the global environment
#' @import RCurl
#' @export
#' @details Updates key tables from CSV URLs hosted on Google Drive
#' @examples
#' \donttest{
#' updateData()
#' }
#' @author David Wilks

updateData <- function(){
	dailyUrl <- "https://445e25c38fe5febd57a1ba9aaadcfb38a45b1d60.googledrive.com/host/0BxMhz1SiiE9Ca2lITU1femVvSkk"
	hourlyUrl <- "https://33e8874943d6cf5d9b8f074df58eeea08c58c23a.googledrive.com/host/0BxMhz1SiiE9CSGRSYkh1T3VEaFU"
	sparseUrl <- "https://321930d0d57e9855f0b67a985e63b0a402e9eadf.googledrive.com/host/0BxMhz1SiiE9CcXpsSmtnS3FBdFk"
	startsUrl <- "https://25eff1d288113bc8575552215cb5ccd9713d5ec4.googledrive.com/host/0BxMhz1SiiE9CU0Q1YnNmc2pDMTg"
	contentUrl <- "https://ede73a1663564a3532d6ee41e478f5a872ca4292.googledrive.com/host/0BxMhz1SiiE9CTnVWdG5Ob1ZzWTQ"
	serviceUrl <- "https://3341d7315c73f3212f6534beaa7863b78cb50358.googledrive.com/host/0BxMhz1SiiE9CQ2JLUlV4TnloZTg"
												
	if (!url.exists(dailyUrl)) {
		warning ('daily table download failed')
	} else {
		daily <- read.csv(text = getURL(dailyUrl),stringsAsFactors = FALSE, 
														check.names = FALSE)
		daily <- daily[,-c(1)]
		daily[,1] <- as.Date(daily[,1], format = '%Y-%m-%d')
		assign('daily', daily, envir = .GlobalEnv)
	}
	if (!url.exists(hourlyUrl)) {
		warning ('hourly table download failed')
	} else {
		hourly <- read.csv(text = getURL(hourlyUrl),stringsAsFactors = FALSE, 
															check.names = FALSE)
		hourly <- hourly[,-c(1)]
		hourly[,1] <- as.POSIXct(strptime(hourly[,1],format="%Y-%m-%d %H:%M:%S", tz = 'GMT'))
		assign('hourly', hourly, envir = .GlobalEnv)
	}
	if (!url.exists(sparseUrl)) {
		warning ('sparse table download failed')
	} else {
		sparse <- read.csv(text = getURL(sparseUrl),stringsAsFactors = FALSE, 
					header = FALSE, check.names = FALSE)
		colNames <- sparse[,2]
		sparse <- sparse[,-c(1,2)]
		dts <- sparse[1,]
		sparse <- sparse[-c(1),]
		sparse <- as.data.frame(t(as.matrix(sapply(sparse, as.numeric))))
		sparse <- cbind(t(dts), sparse)
		names(sparse) <- colNames
		assign('sparse', sparse, envir = .GlobalEnv)
	}	
	if (!url.exists(startsUrl)) {
		warning ('govUkStarts table download failed')
	} else {
		govUkStarts <- read.csv(text = getURL(startsUrl), stringsAsFactors = FALSE)
		assign('govUkStarts', govUkStartsBySourceMedium, envir = .GlobalEnv)
	}	
	if (!url.exists(contentUrl)) {
		warning ('govUkContent table download failed')
	} else {
		govUkContent <- read.csv(text = getURL(contentUrl), stringsAsFactors = FALSE)
		assign('govUkContent', govUkContent, envir = .GlobalEnv)
	}	
	if (!url.exists(serviceUrl)) {
		warning ('serviceSummaries table download failed')
	} else {
		serviceSummaries <- read.csv(text = getURL(serviceUrl), stringsAsFactors = FALSE)
		assign('serviceSummaries', transactionalServiceSummaries, envir = .GlobalEnv)
	}	
	getEconomicData()
}
