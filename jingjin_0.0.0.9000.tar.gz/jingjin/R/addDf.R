#' Aggregate services across dataframe
#'
#' Apply a custom function across a whole dataframe.
#' 
#' Each column in sparse, daily and hourly is one variable from one JSON URL.
#' Several columns may be needed to define a service and they may needed to be
#' aggregated in non-straightforward ways. This function takes a function which
#' identifies all the relevant service names from a dataframe and applies a 
#' custom aggregation function across them.
#' See getSatisfaction() for an example of how to build on this.
#' 
#' @param dFrame A dataframe
#' @param getServices A function identifying services with relevant data
#' @param f A function to aggregate data from each service
#' @return A dataframe
#' @export
#' @examples
#' aggDf(sparse, getSatisServices, getServiceSatisfaction)
#' @author David Wilks

aggDf <- function(dFrame, getServices, f) {
	if (!is.data.frame(dFrame)||!is.function(getServices)||!is.function(f)) {
		stop ('Parameters not of expected types - see ?aggDf')
	}
	aggServices(dFrame, getServices(dFrame), f)
}