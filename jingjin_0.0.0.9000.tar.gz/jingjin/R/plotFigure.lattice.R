#' The plotFigure.lattice function
#' 
#' This function implement a lattice graph method for "lattice" class argument of the 
#' generic plotFigure function.
#' @param dataset, A dataset of "lattice" class.
#' @family plotFigure
#' @export
#' @import ggplot2
#' @examples
#' doi <- getDataOfInterest("2014-04-01", "2015-03-05", "register-to-vote", "age_band", daily)
#' doiLatticeChart <- selectFigureType(doi, "lattice")
#' plotFigure(doiLatticeChart)
#' @author Jing Jin

plotFigure.lattice <- function(dataset) {
  df <- toDataFrame(dataset)
  gg <- ggplot2::ggplot(df, ggplot2::aes(x = date, y = data, col = factor(legend)))
  gg <- gg + ggplot2::geom_line() + ggplot2::theme(legend.position="none")
  gg <- gg + ggplot2::facet_wrap(~legend)
  gg
}