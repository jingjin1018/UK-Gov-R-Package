#' Adjust a dataframe for seasonality
#'
#' Parse dataframe to interpolate NAs and work out periodicity of timeseries
#' Gives a choice to apply R's decompose function or a moving weekly average
#' The moving weekly average is a very short function HEAVILY BASED on StackOverflow
#' See ?movingWeeklyAverage
#'
#' @param s A dataframe of which the first column gives dates
#' @param returnType Either 'weeklyAverage' or one of the standard parameters of decompose: x, seasonal, figure, trend or random
#' @return A dataframe with all series adjusted for seasonality or weekly patterns
#' @details
#' Examine non-null rows to see if they conform to timeseries pattern, interpolates NAs and then adjusts for seasonality
#' @importFrom lubridate yday quarter month year day is.Date week
#' @export
#' @examples
#' cols <- names(daily)[subsetByKeywords(daily,'driving-test-practical','online')]
#' getSeasonal(daily[,c('dt',cols)],'trend')
#' getSeasonal(daily[,c('dt',cols)],'weeklyAverage')
#' @author David Wilks

getSeasonal <- function (s, returnType) {
	if (!is.data.frame(s)||!is.Date(s[,1])||!all(as.logical(lapply(s[,2:ncol(s)], is.numeric))))
		stop ("First argument must be a dataframe with first column as date and all other columns numeric")
	returnType = match.arg(returnType, c('weeklyAverage', 'x', 'seasonal', 'figure', 'trend', 'random'))
	if (ncol(s) > 2) { 
		s <- s[rowSums(is.na(s[,2:ncol(s)])) != ncol(s)-1,]
	} else {
		s <- s[!is.na(s[,2]),]
	}
	period <- 'day'
	if (length(unique(weekdays(s[,1])))==1) period <- 'week'
	if (length(unique(day(s[,1])))==1) period <- 'month'
	checkAllInteger <- function (x) all(x == as.integer(x))
	if (period == 'month' && checkAllInteger((month(s[,1])-min(month(s[,1])))/3)) period <- 'quarter' 
	  
	if (period == 'quarter') {
		dts <- year(s[,1]) * 4 + quarter(s[,1])
		start <- c(year(s[1,1]), quarter(s[1,1]))
		end <- c(year(s[nrow(s),1]), quarter(s[nrow(s),1]))
		freq <- 4 
	} else if (period == 'month') {
		dts <- year(s[,1]) * 12 + month(s[,1])
		start <- c(year(s[1,1]), month(s[1,1]))
		end <- c(year(s[nrow(s),1]), month(s[nrow(s),1]))
		freq <- 12 
	} else if (period == 'week') {
		dts <- year(s[,1]) * 52 + week(s[,1])
		start <- c(year(s[1,1]), week(s[1,1]))
		end <- c(year(s[nrow(s),1]), week(s[nrow(s),1]))
		freq <- 52 	
	} else { 
		dts <- as.integer(s[,1])
		start <- c(year(s[1,1]), yday(s[1,1]))
		end <- c(year(s[nrow(s),1]), yday(s[nrow(s),1]))
		freq <- 365 	
	}

	len <- end[[1]] * freq + end[[2]] - start[[1]] * freq - start[[2]] + 1	
	dts <- dts - dts[1] + 1
	df <- data.frame(Dt=seq.Date(s[1,1], s[nrow(s),1], by = period))
	if (returnType == 'weeklyAverage' && (period != 'day' || len <= 7)) 
		stop ('To apply weekly average, data must be daily with > 7 values')
	if (length(dts) < 0.5 * len) stop ('Data too sparse to run function')
	for (c in 2:ncol(s)) {
		sCol <- rep(NA,length(df)) 
		sCol[dts] <- s[,c]
		if (sum(is.na(sCol)) > 0.5 * len) warning (paste('Data is very sparse in column',c))
		if (returnType == 'weeklyAverage') {
			df <- cbind(df, movingWeeklyAvg(interpNA(sCol)))
		} else {
			df <- cbind(df, as.double(decompose(ts(interpNA(sCol), start, end, freq))[[returnType]]))  
		}
	}
	if (ncol(df) > 2) {
		df <- df[rowSums(is.na(df[,2:ncol(df)])) != ncol(df)-1,]
	} else {
		df <- df[!is.na(df[,2]),]
	}
	colnames(df) <- colnames(s)
	df
}


