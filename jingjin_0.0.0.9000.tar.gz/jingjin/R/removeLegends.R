#' The removeLegends function
#' 
#' This function removes certain legends specified in a list from the figure.
#' @param dataset, The dataset one wants to visualize. The class of this dataset determines the type of the generated plot. 
#' @param removeList, A list specifies the legends one wants to remove from the plot.
#' @export
#' @examples
#' doi <- getDataOfInterest("2014-04-01", "2015-03-05", "register-to-vote", "age_band", daily)
#' doiLineChart <- selectFigureType(doi, "line")
#' removeLegends(doiLineChart, c("age_band__21-30", "age_Band__25-34"))
#' @author Jing Jin

removeLegends <- function(dataset, removeList) {
  dataset <- removeCols(dataset, removeList)
  plotFigure(dataset)
}