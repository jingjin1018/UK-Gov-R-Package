#' The plotFigure.bar function
#' 
#' This function implement a bar chart method for "bar" class argument of the 
#' generic plotFigure function.
#' @param dataset, A dataset of "bar" class.
#' @family plotFigure
#' @export
#' @import ggplot2
#' @examples
#' doi <- getDataOfInterest(startDate = "2015-03-02", urlKeywords = "pay-register-death-abroad", varKeywords = "uniqueEvents", dataset = sparse)
#' doiBarChart <- selectFigureType(doi, "bar")
#' plotFigure(doiBarChart)
#' @author Jing Jin

plotFigure.bar <- function(dataset) {
  df <- toDataFrame(dataset)
  gg <- ggplot2::ggplot(df, ggplot2::aes(x = legend, y = data, fill=factor(legend)))
  gg <- gg + ggplot2::geom_bar(stat = "identity", position = "dodge")
  gg <- gg + ggplot2::scale_fill_discrete(name="Legend")
  gg <- gg + ggplot2::theme(axis.text.x = ggplot2::element_blank())
  gg <- gg + ggplot2::geom_text(ggplot2::aes(label = paste(data), y = data + 0.3, x = legend), size = 3)
  gg
}
