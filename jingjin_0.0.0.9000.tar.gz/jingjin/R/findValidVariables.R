#' The findValidVariables function
#' 
#' This function provides a vector of valid variables corresponding to certian keywords in a dataset.
#' @param urlKeywords, A character vector of URL keywords.
#' @param dataset, A dataset from which one wants to find the valid variables corresponding to the keywords.
#' @export
#' @return A vector of valid variables corresponding to the keywords.
#' @examples
#' vars <- findValidVariables("pay-foreign-marriage-certificates", sparse)
#' @author Jing Jin

findValidVariables <- function(urlKeywords, dataset) {
  vars <- dataFrameIndex(dataset[ , subsetByKeywords(dataset, urlKeywords)])
  unique(unlist(vars[[2]]))
}
