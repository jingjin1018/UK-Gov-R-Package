#' The toDataFrame function
#' 
#' Extract the data in dataset, remove the NA values, extract legend from URLs and rearrange it into a data.frame.
#' @param dataset, The dataset which one wants to extract data from.
#' @export
#' @return Returns a data.frame with no NA entry.
#' @examples
#' \donttest{
#' doi <- getDataOfInterest("2014-04-01", "2015-03-05", "register-to-vote", "age_band", daily)
#' doiLineChart <- selectFigureType(doi, "line")
#' df <- toDataFrame(doiLineChart)
#' }
#' @author Jing Jin

toDataFrame <- function(dataset) {
  numNAEntries <- lapply(lapply(dataset, is.na), sum)
  dataset <- dataset[numNAEntries != length(dataset$date)]
  len <- length(dataset)
  df <- data.frame(date = as.Date(character()), data = numeric(), legend = character())
  legend <- as.vector("character")
  for(i in 2:len) {
    line <- dataset[[i]]
    naIndex <- is.na(line)
    line <- line[!naIndex]
    date <- as.Date(dataset$date[!naIndex], "%Y-%m-%d")
    legend[i-1] <- sub("(.*)___", "", names(dataset)[i])
    newDf <- data.frame(date = date, data = line, legend = legend[i-1])
    df <- rbind(df, newDf)
  }
  if(length(legend) > 1) {
    df$legend <- removeCommonPrefix(unlist(df$legend))
  }
  df
}
