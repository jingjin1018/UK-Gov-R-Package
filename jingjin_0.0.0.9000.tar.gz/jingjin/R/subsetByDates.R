#' The subsetByDates function
#' 
#' Returns the index of a subset of dates between start date and end date in certain period. 
#' If the end date is missing, this function returns the index of start date. 
#' @param startDate, The first date of interest. Valid format: "YYYY-MM-DD".
#' @param endDate, The last date of interest(Optional). Valid format: "YYYY-MM-DD".
#' @param dateRange, A vector of dates, which stands for the period to be subsetted.
#' @export
#' @examples
#' from <- "2015-03-01"
#' to <- "2015-03-11"
#' dateRange <- seq.Date(as.Date("2015-01-01"), as.Date("2015-04-01"), by="day")
#' subsetByDates(from, to, dateRange)
#' @author Jing Jin

subsetByDates <- function(startDate, endDate = startDate, dateRange) {
  startIndex <- getIndexByDate(startDate, dateRange)
  endIndex <- getIndexByDate(endDate, dateRange)
  seq(startIndex, endIndex, 1)
}
