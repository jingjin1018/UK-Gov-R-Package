library(testthat)
library(jingjin)

test_check("jingjin")
