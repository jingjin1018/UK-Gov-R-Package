## author: Jing Jin

context("selectFigureType")

test_that("The output R object class changed when the figure type belongs to {line, area, bar, lattice}", {
  data <- data.frame(c(1:9), letters[1:9])
  dataLine <- selectFigureType(data, "line")
  dataArea <- selectFigureType(data, "area")
  dataBar <- selectFigureType(data, "bar")
  dataLattice <- selectFigureType(data, "lattice")
  expect_that(dataLine, is_a("line"))
  expect_that(dataArea, is_a("area"))
  expect_that(dataBar, is_a("bar"))
  expect_that(dataLattice, is_a("lattice"))
})

test_that("Invalid figure type throws an error", {
  data <- data.frame(c(1:9), letters[1:9])
  expect_that(selectFigureType(data, "pie"), throws_error())
})