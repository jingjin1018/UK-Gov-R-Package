## author:Jing Jin

context("getDataOfInterest")

test_that("the dates are in the interested duration", {
  startD <- "2013-04-01"
  endD <- "2015-03-05"
  data <- getDataOfInterest(startD, endD, "register-to-vote", "age_band", daily)
  expect_that(all(as.Date(data$date) >= as.Date(startD)), is_true())
  expect_that(all(as.Date(data$date) <= as.Date(endD)), is_true())
})

test_that("search for a keyword that doesn't exist in the dataset only returns the dates", {
  # The column names of data are:
  # [1] "dt"  
  # [2] "solihull-local-authority/transactions-by-channel__count____Digital__Digital__Webform"
  # [3] "solihull-local-authority/transactions-by-channel__count____FaceToFace__NonDigital__Area Housing Office"
  keyword <- "register-to-vote"
  data <- daily[, c(2:4)]
  doi <- getDataOfInterest("2013-04-01", "2015-03-05", "register-to-vote", dataset = data)
  expect_that(doi, is_a("Date"))
})

test_that("search for a variable that doesn't exist in the dataset only returns the dates", {
  # The column names of data are:
  # [1] "dt"  
  # [2] "solihull-local-authority/transactions-by-channel__count____Digital__Digital__Webform"
  # [3] "solihull-local-authority/transactions-by-channel__count____FaceToFace__NonDigital__Area Housing Office"
  variable <- "rating"
  data <- daily[, c(2:4)]
  doi <- getDataOfInterest("2013-04-01", "2015-03-05", "transactions-by-channel", variable, dataset = data)
  expect_that(doi, is_a("Date"))
})

test_that("missing keywords and variables throws an error", {
  data <- daily[, c(2:4)]
  expect_that(getDataOfInterest("2013-04-01", "2015-03-05", dataset = data), throws_error())
})