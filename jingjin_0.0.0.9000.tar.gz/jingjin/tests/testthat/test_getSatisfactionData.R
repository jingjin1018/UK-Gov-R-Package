## getSatisfactionData() calls on all the other satisfaction
## and aggregation functions (i.e. with names beginning 'agg').
## If it works, this should show that the others do too.
## Check that it returns a reasonable size dataframe and that
## all values are between zero and 1.

test_that("Check getSatisfactionData() is working", {
	s <- getSatisfactionData()
	expect_true(nrow(s)>10)
	expect_true(ncol(s)>10)
	expect_true(max(s[,2:ncol(s)],na.rm=TRUE) <= 1)
	expect_true(min(s[,2:ncol(s)],na.rm=TRUE) >= 0)
})