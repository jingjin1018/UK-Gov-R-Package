test_that("Subset functionality working", {
	m <- subsetByKeywords(daily,varKeywords = 'Safari')
	mPartial <- subsetByKeywordsPartialRegex(daily,'Safari')
	expect_true(sum(m)>=8)
	expect_true(length(mPartial) > sum(m))
})