## author:Jing Jin

context("plotCorMatrix")

test_that("plotCorMatrix works for the output of function getDataOfInterest", {
  doi <- getDataOfInterest("2014-04-01", "2015-03-05", "register-to-vote", c("18-24", "25-34", "35-44", "45-54", "55-64", "65-74"), daily)
  cor <- correlationMatrix(doi)
  p <- plotCorMatrix(cor)
  expect_that(p, is_a("ggplot"))
})

test_that("matrix with entries out of valid range of correlation coefficient throws an error", {
  cor <- matrix(c(3:11)*0.1, 3, 3)
  expect_error(plotCorMatrix(cor))
})