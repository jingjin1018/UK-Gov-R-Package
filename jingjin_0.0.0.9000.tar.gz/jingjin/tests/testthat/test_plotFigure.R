## author: Jing Jin

context("plotFigure")

test_that("plotFigure works for line class", {
  doi <- getDataOfInterest("2014-04-01", "2015-03-05", "register-to-vote", "age_band", daily)
  doiLineChart <- selectFigureType(doi, "line")
  p <- plotFigure(doiLineChart)
  expect_that(p, is_a("ggplot"))
})

test_that("plotFigure works for area class", {
  doi <- getDataOfInterest("2014-04-01", "2015-03-05", "register-to-vote", "age_band", daily)
  doiAreaChart <- selectFigureType(doi, "area")
  p <- plotFigure(doiAreaChart)
  expect_that(p, is_a("ggplot"))
})

test_that("plotFigure works for bar class", {
  doi <- getDataOfInterest(startDate = "2015-03-02", urlKeywords = "pay-register-death-abroad", varKeywords = "uniqueEvents", dataset = sparse)
  doiBarChart <- selectFigureType(doi, "bar")
  p <- plotFigure(doiBarChart)
  expect_that(p, is_a("ggplot"))
})

test_that("plotFigure works for lattice class", {
  doi <- getDataOfInterest("2014-04-01", "2015-03-05", "register-to-vote", c("18-24", "25-34", "35-44", "45-54"), daily)
  doiLatticeChart <- selectFigureType(doi, "lattice")
  p <- plotFigure(doiLatticeChart)
  expect_that(p, is_a("ggplot"))
})

