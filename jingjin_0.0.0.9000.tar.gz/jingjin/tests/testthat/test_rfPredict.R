## The following repeats the example from the functions because it's very hard
## to find suitable series for machine learning in the transactional data 

test_that("Machine learning functionality working", {
	d <- daily[,c('dt',names(daily)[subsetByKeywords(daily,'register-to-vote')])]
	p <- rfPredict(d, 'register.to.vote.volumetrics__count____age_band__45.54')
	expect_true(is.numeric(p))
	expect_equal(length(p),7)
})