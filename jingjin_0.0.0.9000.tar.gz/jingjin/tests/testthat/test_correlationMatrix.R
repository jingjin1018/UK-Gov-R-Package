## author: Jing Jin

context("correlationMatrix")

test_that("correlationMatrix generates valid results", {
  vars <- c("18-24", "25-34", "35-44", "45-54", "55-64", "65-74")
  doi <- getDataOfInterest("2014-04-01", "2015-03-05", "register-to-vote", vars, daily)
  cor <- correlationMatrix(doi)
  expect_that(dim(cor)[1], equals(length(vars)))
  expect_that(dim(cor)[1], equals(dim(cor)[2]))
  expect_that(all(cor <= 1), is_true())
  expect_that(all(cor >= -1), is_true())
})