## author: Jing Jin

context("removeLegends")

test_that("removeLegends removes the columns specified", {
  doi <- getDataOfInterest("2014-04-01", "2015-03-05", "register-to-vote", "age_band", daily)
  doiLineChart <- selectFigureType(doi, "line")
  p1 <- plotFigure(doiLineChart)
  cols <- c("51-60", "55-64", "61-70", "65-74", "> 70", "> 75", "not_provided")
  p2 <- removeLegends(doiLineChart, cols)
  expect_that(p1, is_a("ggplot"))
  expect_that(p2, is_a("ggplot"))
  expect_that(length(levels(as.factor(p1$data$legend))) - length(levels(as.factor(p2$data$legend))), equals(length(cols)))
})
  
test_that("remove an empty list from dataset throws a warning", {
  doi <- getDataOfInterest("2014-04-01", "2015-03-05", "register-to-vote", c("51-60", "55-64", "61-70"), daily)
  doiLineChart <- selectFigureType(doi, "line")
  cols <- character()
  expect_that(removeLegends(doiLineChart, cols), gives_warning("Empty remove list"))
})

test_that("remove data doesn't exist in the dataset throws a warning", {
  doi <- getDataOfInterest("2014-04-01", "2015-03-05", "register-to-vote", c("51-60", "55-64", "61-70"), daily)
  doiLineChart <- selectFigureType(doi, "line")
  cols <- c("21-30", "25-34")
  expect_that(removeLegends(doiLineChart, cols), gives_warning())
})