## Web interface for exploring the UK Gov performance data
## author: Jing Jin

library(shiny)
library(jingjin)

shinyServer(
  function(input, output){
    
    keys <- reactive({
      switch(input$dataset,
             "daily" = as.character(getKeywords(list(daily))[[1]]$x),
             "hourly" = as.character(getKeywords(list(hourly))[[1]]$x),
             "sparse" = as.character(getKeywords(list(sparse))[[1]]$x))
    })
    
    vars <- reactive({
      findValidVariables(as.character(input$keywords), get(input$dataset))            
    })
    
    output$mykeys <- renderUI({
      selectInput("keywords", "Select keywords: ", choices = keys(), multiple = TRUE)
    })
    
    output$myvars <- renderUI({
      selectInput("variables", "Select variables: ", choices = vars(), multiple = TRUE)
    })
    
    output$dHelp <- renderText({
      paste("The valid date range for dataset ", input$dataset, " is: ", range(get(input$dataset)$dt)[1], " - ", range(get(input$dataset)$dt)[2], sep = "")
    })
    
    data <- reactive({
      if(input$ptype == "bar") {
        endDate <- input$startD
      } else {
        endDate <- input$endD
      }
      doi <- getDataOfInterest(input$startD, endDate, as.character(input$keywords), as.character(input$variables), get(input$dataset))
    })
   
    output$plot <- renderPlot({
      if(input$action == 0) {
        return()
      } else {
        isolate(mydata <- selectFigureType(data(), as.character(input$ptype)))
        isolate(plotFigure(mydata))
      }
    })
    
    output$str <- renderPrint({
      if(input$action == 0) {
        return(paste("Empty page. Waiting for the input ..."))
      } else {
        isolate(mydata <- selectFigureType(data(), as.character(input$ptype)))
        isolate(str(mydata))
      }
    })
  }
)