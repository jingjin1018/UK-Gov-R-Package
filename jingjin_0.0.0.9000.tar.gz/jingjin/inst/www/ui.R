## Web interface for exploring the UK Gov performance data
## author: Jing Jin

library(shiny)
library(jingjin)

shinyUI(fluidPage(
  titlePanel("Shiny Interface: UK Gov Performance Analysis"),
  sidebarLayout(
    sidebarPanel(
      selectInput("dataset", "Please select the dataset: ", c("daily", "hourly", "sparse"), selected = "daily"),
      uiOutput("mykeys"),
      br(),
      uiOutput("myvars"),
      br(),
      selectInput("ptype", "Please select the plot type: ", c("line", "area", "bar", "lattice"), selected = "line"),
      p("For bar chart, only the observations at the start date is plotted. The entry of last date  is discarded."),
      br(),
      textInput("startD", "Please enter the start date of your interest: ", value = "2014-04-01"),
      br(),
      textInput("endD", "Please enter the last date of your interest: ", value = "2015-03-01"),
      textOutput("dHelp"),
      br(),
      actionButton("action", "Update the plot!"),
      p("Click on the Update button to update the plot.")
      ),
    mainPanel(
      tabsetPanel(type = "tab",
                  tabPanel("Plot", plotOutput("plot")),
                  tabPanel("Structure", verbatimTextOutput("str"))
      )
    )
  )
)
)