## Author: David Wilks

import httplib2, unicodedata, json, pandas as pd, urllib, datetime, sys, numpy as np, urllib2
from unidecode import unidecode
from bs4 import BeautifulSoup, SoupStrainer
from time import sleep
from pydrive.auth import GoogleAuth
from pydrive.drive import GoogleDrive

http = httplib2.Http()	## GET LIST OF JSON URLS TO SCRAPE
ppLinks = []
jsonLinks = []
scrapedLinks = []
linksToScrape = []
url = 'https://www.gov.uk/performance/services'
i = 0
	
while (len(linksToScrape) > 0 or len(scrapedLinks) == 0) and i < 3000:
    sleep(0.3)
    i = i + 1
    try:
        status, response = http.request(url)
        for link in BeautifulSoup(response, parseOnlyThese=SoupStrainer('a')):
            if link.has_attr('href'):
                link = unicodedata.normalize('NFKC', link.decode()).encode('ascii','ignore')
                if link[0:7] == '<a href':
                    if link.find('png') == -1:
                        link = link[link.index('=')+1:link.index('>')].replace('"','').replace(' ','')
                        if link.find('?') > -1: link = link[:link.index('?')]		
                        if link.find('www.gov.uk/performance') > -1: ppLinks.append(link)
                        elif link.find('/performance') == 0: ppLinks.append('https://gov.uk' + link)
                        elif link.find('www.performance.service.gov.uk') > -1: jsonLinks.append(link)
    except:
        i=i+1

    scrapedLinks.append(url)
    ppLinks = list(set(ppLinks))
    jsonLinks = list(set(jsonLinks))
    linksToScrape = list(set(ppLinks) - set(scrapedLinks))
    if len(linksToScrape) > 0: url = linksToScrape[0]
	
t = pd.datetime.today()						## MAKE MASTER DATE LISTS (by days, hours)
s = datetime.datetime(2010, 4, 1, 0, 0)
h = (t - s).days * 24
d = (t - s).days	
m = pd.DataFrame(pd.date_range(s, freq='H', periods=h))
m.columns = ['dt']
md = pd.DataFrame(pd.date_range(s, periods=d))
md.columns = ['dt']
mC = m[:]
mdC = md[:]

govUkContent = []
govUkContentUrls = []
brokenPages = []

for rpt in range(0,2):
	for i in range(0, len(jsonLinks)):			## SCRAPE JSON
		pd.DataFrame([i]).to_csv('i2.csv')
		url = jsonLinks[i]
		sleep(0.3)
		if url.find('govuk/most_viewed') > -1: continue
		try:
			df = pd.DataFrame(json.loads(urllib.urlopen(url).read())['data'])
			df.columns = [str(x) for x in df.columns]
		
			if url.find('realtime') > -1:
				keepGoing = False
				df = df.ix[:,['_id','for_url','unique_visitors']][:]
				if 'realTime' in locals(): realTime = realTime.append(df)
				else: realTime = df
				continue
			elif url.find('transactional-services/summaries') > -1:
				trServicesSummaries = df
				continue
			elif url.find('gov-uk-starts-by-source-medium') >-1:		
				gov_uk_starts_by_source_medium = df
				continue
			
			conc = [] 
			vals = []
			
			for c in df.columns:
				if type(max(df[c])) == unicode and not(c in ['_day_start_at', '_end_at', '_hour_start_at', '_id', \
						'_month_start_at', '_quarter_start_at', '_start_at', '_timestamp', '_updated_at', \
						'_week_start_at', '_year_start_at', 'humanId']):
					if len(df[c].unique()) != 1:
						conc.append(c)	
				elif type(df[c][0]) == np.float64 or type(df[c][0]) == np.int64:
						vals.append(c)
			
			if 2 * len(df['_day_start_at'].unique()) > len(df['_hour_start_at'].unique()): 
				timeString = '_day_start_at'
			else: 
				timeString = '_hour_start_at'
								
			df['concat'] = ''
			
			if len(conc) > 0 and url.find('gov-uk-content') == -1:
				for j in range(0,len(conc)):
					df[conc[j]] = df[conc[j]].replace(np.nan,'')
					df['concat'] = df['concat'] + '__' + df[conc[j]]
			
			dedup = vals[:]
			if url.find('gov-uk-content') > -1: 
				for cI in range(0,len(conc)): dedup.append(conc[cI])
			elif len(conc) > 0: dedup.append('concat')
			dedup.append(timeString)
			df = df.ix[:,dedup][:]
			df.drop_duplicates(dedup,inplace=True)
			df.rename(columns={timeString:'dt'}, inplace=True)
						
			if len(conc) > 0 and url.find('gov-uk-content') == -1:
				p = df.pivot('dt','concat')[vals[0]]
				if type(p) != pd.core.frame.DataFrame:
					p = pd.DataFrame(p)
				p.columns = [url + '__' + vals[0] + '__' + x.replace(":","-") for x in p.columns]
				p['dt'] = ''
				p['dt'] = p.index
				
				if len(vals) > 1:
					for j in range(1, len(vals)):
						p1 = p
						p2 = df.pivot('dt','concat')[vals[j]]
						if type(p2) != pd.core.frame.DataFrame:
							p2 = pd.DataFrame(p2)				
						p2.columns = [url + '__' + vals[j] + '__' + x.replace(":","-") for x in p2.columns]
						p2['dt'] = p2.index
						p1['dt2'] = p1['dt']
						p = pd.merge(p1,p2,on='dt')
						if 'dt' in p.columns: p.drop('dt', axis=1, inplace=True)
						p.rename(columns={'dt2':'dt'}, inplace=True)
			else:
				p = df
				pCols = list(p.columns)[:]
				pCols = ['dt' if x == 'dt' else url + '__' + vals[0] + '__' + x.replace(":","-") for x in pCols]
				p.columns = pCols
	
			if url.find('gov-uk-content') == -1:
				p['dt'] = pd.to_datetime(p.dt)
				if timeString == '_hour_start_at':
					m = pd.merge(m, p, how='left', on='dt')
					if len(m) > h: sys.exit()
					m['dt'] = mC
				else: 
					md = pd.merge(md, p, how='left', on='dt')
					if len(md) > d: sys.exit()
					md['dt'] = mdC
				
			else:
				govUkContent.append(df)
				govUkContentUrls.append(url)

		except:
			brokenPages.append(url)
			continue	

	jsonLinks = brokenPages
	brokenPages = []
				
md.columns = [col.replace('https://www.performance.service.gov.uk/data/', '') for col in md.columns]
m.columns = [col.replace('https://www.performance.service.gov.uk/data/', '') for col in m.columns]

## separate md into 2 tables (one with columns populated only sparsely)

mdCtValuesByRow = md.count(axis=1)
mdSparseRows = md.ix[mdCtValuesByRow < 100,:][:]
mdCtByColOverSparseRows = mdSparseRows.count()
includeCol = mdCtByColOverSparseRows==0
includeCol[0] = True
mdSparse = md.ix[mdCtValuesByRow >= 100,includeCol][:]
mdNonSparse = md.ix[:,mdCtByColOverSparseRows>0][:]

if len(govUkContent) > 0:
	govUkContentCols = []
	for i in range(0,len(govUkContent)):
		govUkContentCols = govUkContentCols + govUkContent[i].columns.tolist()
	govUkContentCols = list(set(govUkContentCols)) # make unique	
	for i in govUkContentCols:
		if not(i in govUkContent[0].columns):
			govUkContent[0][i] = ''
	govUkContentFrame = govUkContent[0][:]
	for i in range(1,len(govUkContent)):
		govUkContentFrame.append(govUkContent[i])

## Fix unicode that otherwise stops CSV being written

mdc = []
for i in range(0,len(mdSparse.columns)):
	mdc.append(unidecode(mdSparse.columns[i]))	
mdSparse.columns = mdc

contentC = []
for i in range(0,len(govUkContentFrame.columns)):
	contentC.append(unidecode(govUkContentFrame.columns[i]))	
govUkContentFrame.columns = contentC


cols = []
for i in range(0,len(govUkContentFrame.columns)):
	if str(type(govUkContentFrame.ix[2,i])) == "<type 'unicode'>":
		cols.append(i)
		
typ = type(govUkContentFrame.ix[2,4])
		
for i in range(0,len(govUkContentFrame)):
	for c in cols:
		try:
			govUkContentFrame.ix[i,c] = unidecode(govUkContentFrame.ix[i,c])
		except:
			continue	

## Drop verbose repetitive date columns

trServicesSummaries.drop(['_day_start_at', '_month_start_at', '_quarter_start_at', '_week_start_at', '_year_start_at'], axis=1, inplace=True)
gov_uk_starts_by_source_medium.drop(['_day_start_at', '_month_start_at', '_quarter_start_at', '_week_start_at', '_year_start_at'], axis=1, inplace=True)


## Transpose Sparse to help it load in R or spreadsheet application

mdSparse2 = pd.DataFrame(np.transpose(np.array(mdSparse)))
mdSparse2.insert(0, 'colnames', mdSparse.columns)

## Upload to Google Drive - THIS PART ONLY WORKS ON DWILKS' LAPTOP
## Another user would need to adjust it for their file structure and authentication

## gauth = GoogleAuth()  # use google drive for convenience and >10Gb free hosting
## gauth.LocalWebserverAuth()
## drive = GoogleDrive(gauth) # authenticate with google drive
## query = {'q': "trashed=false"} # include subfolder with public web stuff
## file_list = drive.ListFile(query).GetList()

## for f in file_list: # find and update CSV file
## 	if f['title'] == 'ppSparse.csv':
## 		f.SetContentString(mdSparse2.to_csv(header = False))
## 		f.Upload()
## 	elif f['title'] == 'ppSparseNames.csv':
## 		f.SetContentString(pd.DataFrame(mdSparse.columns).to_csv())
## 		f.Upload()
## 	elif f['title'] == 'ppReferrer.csv':
## 		f.SetContentString(gov_uk_starts_by_source_medium.to_csv())
## 		f.Upload()
## 	elif f['title'] == 'ppTxSummary.csv':
## 		f.SetContentString(trServicesSummaries.to_csv())
## 		f.Upload()
## 	elif f['title'] == 'ppGOVUK.csv':
## 		f.SetContentString(govUkContentFrame.to_csv())
## 		f.Upload()
## 	elif f['title'] == 'ppDaily.csv':
## 		f.SetContentString(mdNonSparse.to_csv())
## 		f.Upload()
## 	elif f['title'] == 'ppHourly.csv':
## 		f.SetContentString(m.to_csv())
## 		f.Upload()






