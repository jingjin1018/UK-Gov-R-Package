## ------------------------------------------------------------------------
library('jingjin')
updateData()
getEconomicData()

## ------------------------------------------------------------------------
vars <- findValidVariables("pay-foreign-marriage-certificates", sparse)
head(vars)

## ------------------------------------------------------------------------
dailyIndex <- dataFrameIndex(daily)
length(dailyIndex[[1]])

## ------------------------------------------------------------------------
names(daily)[subsetByKeywords(daily, 'browsers','Android')]

## ------------------------------------------------------------------------
a <- aggDf(sparse, getSatisServices, getServiceSatisfaction)
mean(a[,1],na.rm=TRUE)

## ------------------------------------------------------------------------
doi <- getDataOfInterest("2014-06-30", "2015-03-02", "user-satisfaction",  
                  c("rating_3", "rating_4"), daily)
names(doi)

## ------------------------------------------------------------------------
dailyOutliers <- detectESDoutliers(daily[,3:ncol(daily)])
sum(dailyOutliers)

## ------------------------------------------------------------------------
dts <- c('2013-1-1','2013-4-1','2013-7-1','2013-10-1', 
         '2014-1-1','2014-4-1','2014-7-1','2014-10-1','2015-1-1')
dts <- as.Date(dts, format = '%Y-%m-%d')
d <- data.frame(dt = dts, v = c(1,2,4,8,2,3,5,9,1.5))
getSeasonal(d, 'trend')

## ------------------------------------------------------------------------
df <- daily[,c('dt',names(daily)[subsetByKeywords(daily,'register-to-vote')])]
rfPredict(df, 'register.to.vote.volumetrics__count____age_band__45.54', ntree = 50)

## ----, fig.width = 6, fig.height = 3, fig.align = 'center'---------------
doi <- getDataOfInterest("2014-04-01", "2015-03-05", "register-to-vote", 
                         c("18-24", "25-34", "35-44", "45-54", "55-64", "65-74"), daily)
plotCorMatrix(correlationMatrix(doi))

## ----, fig.width = 6, fig.height = 5, fig.align = 'center'---------------
doi <- getDataOfInterest("2014-04-01", "2015-03-05", "register-to-vote", 
                         c("18-24", "25-34", "35-44", "45-54"), daily)
plotFigure(selectFigureType(doi, "lattice"))

