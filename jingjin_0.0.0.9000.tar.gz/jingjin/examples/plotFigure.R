library(jingjin)

# Line chart
doi <- getDataOfInterest("2014-04-01", "2015-03-05", "register-to-vote",
                         c("18-24", "25-34", "35-44", "45-54"), daily)
doiLineChart <- selectFigureType(doi, "line")
plotFigure(doiLineChart)

# Area chart
doi <- getDataOfInterest("2014-04-01", "2015-03-05", "register-to-vote",
                         c("18-24", "25-34", "35-44", "45-54"), daily)
doiAreaChart <- selectFigureType(doi, "area")
plotFigure(doiAreaChart)

# Bar chart
doi <- getDataOfInterest(startDate = "2015-03-02", urlKeywords = "pay-register-death-abroad", 
                         varKeywords = "uniqueEvents", dataset = sparse)
doiBarChart <- selectFigureType(doi, "bar")
plotFigure(doiBarChart)

# Lattice chart
doi <- getDataOfInterest("2014-04-01", "2015-03-05", "register-to-vote", 
                         c("18-24", "25-34", "35-44", "45-54"), daily)
doiLatticeChart <- selectFigureType(doi, "lattice")
plotFigure(doiLatticeChart)

