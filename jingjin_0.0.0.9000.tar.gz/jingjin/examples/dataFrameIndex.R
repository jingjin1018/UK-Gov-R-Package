library('jingjin')

dailyIndex <- dataFrameIndex(daily)
length(dailyIndex[[1]])