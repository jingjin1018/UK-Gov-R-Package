library('jingjin')

names(daily)[subsetByKeywords(daily, 'browsers','Android')]