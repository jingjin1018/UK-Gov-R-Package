library(jingjin)

doi1 <- getDataOfInterest("2014-06-30", "2015-03-02", "user-satisfaction",  
                         c("rating_3", "rating_4"), daily)
head(doi1)

doi2 <- getDataOfInterest("2014-04-01", "2015-03-05", "register-to-vote", "age_band", daily)
head(doi2)
