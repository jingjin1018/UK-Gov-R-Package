library('jingjin')

dailyOutliers <- detectESDoutliers(daily[,3:ncol(daily)])
sum(dailyOutliers)
