library(jingjin)

keyword <- "pay-foreign-marriage-certificates"
vars <- findValidVariables(keyword, sparse)
vars