library(jingjin)

doi <- getDataOfInterest("2014-04-01", "2015-03-05", "register-to-vote", "age_band", daily)
doiLineChart <- selectFigureType(doi, "line")
plotFigure(doiLineChart)
removeLegends(doiLineChart, c("51-60", "55-64", "61-70", "65-74",
                                           "> 70", "> 75", "not_provided"))
