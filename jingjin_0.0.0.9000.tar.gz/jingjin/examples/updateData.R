library('jingjin')

updateData()
getEconomicData()