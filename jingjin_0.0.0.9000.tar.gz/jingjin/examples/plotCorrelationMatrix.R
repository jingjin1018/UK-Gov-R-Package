library(jingjin)

doi <- getDataOfInterest("2014-04-01", "2015-03-05", "register-to-vote", c("18-24", "25-34", "35-44", "45-54", "55-64", "65-74"), daily)
cor <- correlationMatrix(doi)
cor
plotCorMatrix(cor)
