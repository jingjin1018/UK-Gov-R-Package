library('jingjin')

df <- daily[,c('dt',names(daily)[subsetByKeywords(daily,'register-to-vote')])]
rfPredict(df, 'register.to.vote.volumetrics__count____age_band__45.54', ntree = 50)