library('jingjin')

dts <- c('2013-1-1','2013-4-1','2013-7-1','2013-10-1', '2014-1-1','2014-4-1','2014-7-1','2014-10-1','2015-1-1')
dts <- as.Date(dts, format = '%Y-%m-%d')
d <- data.frame(dt = dts, v = c(1,2,4,8,2,3,5,9,1.5))
getSeasonal(d, 'trend')