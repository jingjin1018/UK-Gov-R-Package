This package has functions to parse, analyse and visualise data from gov.uk/performance.

See the vignette for more details.
